package com.game;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;

@WebServlet(urlPatterns={"/home","/login","/logout","/roles","/attributes","/templates","/role-config","/rules","/calculate"})
public class AppServlet extends HttpServlet {
    private static final Set<String> PAGES=Set.of("/","/login","/logout","/roles","/attributes","/templates","/role-config","/rules","/calculate");
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException {
        String path=req.getServletPath(); if(path.isEmpty()||path.equals("/home"))path="/";
        if(!PAGES.contains(path)){res.sendError(404);return;}
        try {
            if(path.equals("/logout")){res.sendRedirect(req.getContextPath()+"/");return;}
            req.setAttribute("active",path);
            Object flash=req.getSession().getAttribute("flash");req.setAttribute("flash",flash);req.getSession().removeAttribute("flash");
            if(path.equals("/login")){view(req,res,"login");return;}
            req.setAttribute("allRoles",Db.query("SELECT id,name FROM game_role ORDER BY id"));
            req.setAttribute("allTemplates",Db.query("SELECT id,name FROM growth_template ORDER BY id"));
            switch(path){
                case "/" -> {
                    req.setAttribute("stats",Db.query("SELECT (SELECT COUNT(*) FROM game_role) roles,(SELECT COUNT(*) FROM attribute_definition) attributes,(SELECT COUNT(*) FROM growth_template) templates,(SELECT COUNT(*) FROM growth_rule) rules").getFirst());
                    req.setAttribute("recent",Db.query("SELECT r.*,t.name template_name FROM game_role r LEFT JOIN growth_template t ON r.growth_template_id=t.id ORDER BY r.id DESC LIMIT 6"));view(req,res,"dashboard");
                }
                case "/roles","/attributes","/templates" -> {
                    String q=Optional.ofNullable(req.getParameter("q")).orElse("").strip();req.setAttribute("q",q);
                    if(path.equals("/roles"))req.setAttribute("rows",Db.query("SELECT r.*,t.name template_name FROM game_role r LEFT JOIN growth_template t ON r.growth_template_id=t.id WHERE r.name LIKE ? OR r.code LIKE ? ORDER BY r.id DESC","%"+q+"%","%"+q+"%"));
                    if(path.equals("/attributes"))req.setAttribute("rows",Db.query("SELECT * FROM attribute_definition WHERE name LIKE ? OR code LIKE ? ORDER BY sort_order,id","%"+q+"%","%"+q+"%"));
                    if(path.equals("/templates"))req.setAttribute("rows",Db.query("SELECT t.*,(SELECT COUNT(*) FROM growth_rule g WHERE g.template_id=t.id) rule_count FROM growth_template t WHERE name LIKE ? ORDER BY id","%"+q+"%"));
                    if(req.getParameter("edit")!=null){
                        String table=path.equals("/roles")?"game_role":path.equals("/attributes")?"attribute_definition":"growth_template";
                        req.setAttribute("edit",one("SELECT * FROM "+table+" WHERE id=?",positive(req.getParameter("edit"))));
                    }
                    view(req,res,path.substring(1));
                }
                case "/role-config" -> {
                    int id=selection(req,"roleId","allRoles");
                    if(id>0){req.setAttribute("selected",one("SELECT * FROM game_role WHERE id=?",id));req.setAttribute("values",Db.query("SELECT a.*,COALESCE(ra.base_value,0) amount FROM attribute_definition a LEFT JOIN role_attribute ra ON ra.attribute_id=a.id AND ra.role_id=? ORDER BY a.sort_order,a.id",id));}
                    req.setAttribute("selectedId",id);view(req,res,"role-config");
                }
                case "/rules" -> {
                    int id=selection(req,"templateId","allTemplates");
                    if(id>0){req.setAttribute("selected",one("SELECT * FROM growth_template WHERE id=?",id));req.setAttribute("values",Db.query("SELECT a.*,COALESCE(g.per_level,0) amount FROM attribute_definition a LEFT JOIN growth_rule g ON g.attribute_id=a.id AND g.template_id=? ORDER BY a.sort_order,a.id",id));}
                    req.setAttribute("selectedId",id);view(req,res,"rules");
                }
                case "/calculate" -> {
                    int id=selection(req,"roleId","allRoles"); int level=req.getParameter("level")==null?10:positive(req.getParameter("level"));
                    GrowthCalculator.calculate(BigDecimal.ZERO,BigDecimal.ZERO,level);
                    req.setAttribute("selectedId",id);req.setAttribute("level",level);
                    if(id>0){
                        req.setAttribute("selected",one("SELECT r.*,t.name template_name FROM game_role r LEFT JOIN growth_template t ON r.growth_template_id=t.id WHERE r.id=?",id));
                        List<Map<String,Object>> results=Db.query("SELECT a.code,a.name,a.unit,COALESCE(ra.base_value,0) base_value,COALESCE(g.per_level,0) per_level FROM game_role r CROSS JOIN attribute_definition a LEFT JOIN role_attribute ra ON ra.role_id=r.id AND ra.attribute_id=a.id LEFT JOIN growth_rule g ON g.template_id=r.growth_template_id AND g.attribute_id=a.id WHERE r.id=? ORDER BY a.sort_order,a.id",id);
                        for(Map<String,Object> row:results){BigDecimal result=GrowthCalculator.calculate((BigDecimal)row.get("base_value"),(BigDecimal)row.get("per_level"),level);row.put("result",result.stripTrailingZeros().toPlainString());row.put("gain",result.subtract((BigDecimal)row.get("base_value")).stripTrailingZeros().toPlainString());}
                        req.setAttribute("results",results);
                    }
                    view(req,res,"calculate");
                }
            }
        } catch(IllegalArgumentException e){showError(req,res,400,e.getMessage());}
        catch(SQLException e){getServletContext().log("Database request failed",e);showError(req,res,503,"数据库暂时不可用，请检查连接配置与初始化状态。");}
    }
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException,ServletException {
        String path=req.getServletPath();
        try {
            if(path.equals("/login")){login(req,res);return;}
            if(path.equals("/logout")){req.getSession().invalidate();res.sendRedirect(req.getContextPath()+"/login");return;}
            String action=req.getParameter("action");
            if(!Set.of("/roles","/attributes","/templates","/role-config","/rules").contains(path)){res.sendError(405);return;}
            if(path.equals("/role-config")||path.equals("/rules")){
                boolean role=path.equals("/role-config");int id=positive(req.getParameter(role?"roleId":"templateId"));
                one("SELECT id FROM "+(role?"game_role":"growth_template")+" WHERE id=?",id);
                List<Map<String,Object>> attrs=Db.query("SELECT id FROM attribute_definition");
                try(Connection c=Db.open()){
                    c.setAutoCommit(false);
                    try(PreparedStatement s=c.prepareStatement(role?"INSERT INTO role_attribute(role_id,attribute_id,base_value) VALUES(?,?,?) ON DUPLICATE KEY UPDATE base_value=VALUES(base_value)":"INSERT INTO growth_rule(template_id,attribute_id,per_level) VALUES(?,?,?) ON DUPLICATE KEY UPDATE per_level=VALUES(per_level)")){
                        for(Map<String,Object> a:attrs){BigDecimal value=decimal(req.getParameter("value_"+a.get("id")));Db.bind(s,id,a.get("id"),value);s.addBatch();}
                        s.executeBatch();c.commit();
                    }catch(Exception e){c.rollback();throw e;}
                }
                success(req,res,path+"?"+(role?"roleId":"templateId")+"="+id,"配置已保存");return;
            }
            String table=path.equals("/roles")?"game_role":path.equals("/attributes")?"attribute_definition":"growth_template";
            if("delete".equals(action)){Db.update("DELETE FROM "+table+" WHERE id=?",positive(req.getParameter("id")));success(req,res,path,"删除成功");return;}
            if(!"save".equals(action))throw new IllegalArgumentException("无效操作");
            String name=required(req,"name",80);String id=req.getParameter("id");boolean edit=id!=null&&!id.isBlank();
            if(path.equals("/roles")){
                String code=code(req);String profession=required(req,"profession",40);String rarity=required(req,"rarity",10);
                if(!Set.of("R","SR","SSR").contains(rarity))throw new IllegalArgumentException("稀有度无效");
                String tid=req.getParameter("growth_template_id");Integer template=tid==null||tid.isBlank()?null:positive(tid);String description=optional(req,"description",500);
                if(edit)Db.update("UPDATE game_role SET code=?,name=?,profession=?,rarity=?,growth_template_id=?,description=? WHERE id=?",code,name,profession,rarity,template,description,positive(id));
                else Db.update("INSERT INTO game_role(code,name,profession,rarity,growth_template_id,description) VALUES(?,?,?,?,?,?)",code,name,profession,rarity,template,description);
            }else if(path.equals("/attributes")){
                String code=code(req);String unit=optional(req,"unit",20);int order;
                try{order=Integer.parseInt(req.getParameter("sort_order"));}catch(Exception e){throw new IllegalArgumentException("排序必须为整数");}
                if(edit)Db.update("UPDATE attribute_definition SET code=?,name=?,unit=?,sort_order=? WHERE id=?",code,name,unit,order,positive(id));
                else Db.update("INSERT INTO attribute_definition(code,name,unit,sort_order) VALUES(?,?,?,?)",code,name,unit,order);
            }else{
                String description=optional(req,"description",500);
                if(edit)Db.update("UPDATE growth_template SET name=?,description=? WHERE id=?",name,description,positive(id));
                else Db.update("INSERT INTO growth_template(name,description) VALUES(?,?)",name,description);
            }
            success(req,res,path,"保存成功");
        }catch(IllegalArgumentException e){showError(req,res,400,e.getMessage());}
        catch(SQLIntegrityConstraintViolationException e){showError(req,res,409,"编码或名称已存在，或关联记录不存在。请检查后重试。");}
        catch(SQLException e){getServletContext().log("Database mutation failed",e);showError(req,res,503,"保存失败，请检查数据库连接。");}
    }
    private void login(HttpServletRequest req,HttpServletResponse res) throws SQLException,ServletException,IOException {
        HttpSession session=req.getSession();Long until=(Long)session.getAttribute("lockedUntil");
        if(until!=null&&until>System.currentTimeMillis()){req.setAttribute("error","尝试次数过多，请 60 秒后重试");view(req,res,"login");return;}
        String username=required(req,"username",80);String password=required(req,"password",128);
        List<Map<String,Object>> users=Db.query("SELECT * FROM admin_user WHERE username=?",username);
        if(!users.isEmpty()&&Passwords.verify(password,(String)users.getFirst().get("salt"),(String)users.getFirst().get("password_hash"))){
            req.changeSessionId();session.setAttribute("admin",username);session.setAttribute("csrf",UUID.randomUUID().toString());session.removeAttribute("attempts");session.removeAttribute("lockedUntil");res.sendRedirect(req.getContextPath()+"/");
        }else{
            int attempts=session.getAttribute("attempts")==null?1:(Integer)session.getAttribute("attempts")+1;session.setAttribute("attempts",attempts);
            if(attempts>=8){session.setAttribute("lockedUntil",System.currentTimeMillis()+60000);session.setAttribute("attempts",0);}
            req.setAttribute("error","用户名或密码错误");view(req,res,"login");
        }
    }
    private static String code(HttpServletRequest r){String value=required(r,"code",32).toUpperCase(Locale.ROOT);if(!value.matches("[A-Z][A-Z0-9_]{0,31}"))throw new IllegalArgumentException("编码须以英文字母开头，仅包含字母、数字、下划线");return value;}
    private static String required(HttpServletRequest r,String key,int max){String s=optional(r,key,max);if(s.isBlank())throw new IllegalArgumentException("必填字段不能为空："+key);return s;}
    private static String optional(HttpServletRequest r,String key,int max){String s=Optional.ofNullable(r.getParameter(key)).orElse("").strip();if(s.length()>max)throw new IllegalArgumentException("字段过长："+key);return s;}
    private static int positive(String raw){try{int n=Integer.parseInt(raw);if(n<1)throw new NumberFormatException();return n;}catch(Exception e){throw new IllegalArgumentException("编号或等级必须为正整数");}}
    private static BigDecimal decimal(String raw){try{BigDecimal n=new BigDecimal(raw);if(n.signum()<0||n.compareTo(new BigDecimal("999999999.9999"))>0||n.scale()>4)throw new NumberFormatException();return n;}catch(Exception e){throw new IllegalArgumentException("属性数值必须为 0–999999999.9999，最多四位小数");}}
    private static Map<String,Object> one(String sql,Object... args)throws SQLException{List<Map<String,Object>> rows=Db.query(sql,args);if(rows.isEmpty())throw new IllegalArgumentException("记录不存在，请返回列表刷新");return rows.getFirst();}
    @SuppressWarnings("unchecked") private static int selection(HttpServletRequest r,String key,String rows){String raw=r.getParameter(key);if(raw!=null)return positive(raw);List<Map<String,Object>> list=(List<Map<String,Object>>)r.getAttribute(rows);return list.isEmpty()?0:((Number)list.getFirst().get("id")).intValue();}
    private static void view(HttpServletRequest r,HttpServletResponse s,String page)throws ServletException,IOException{r.getRequestDispatcher("/WEB-INF/views/"+page+".jsp").forward(r,s);}
    private static void success(HttpServletRequest r,HttpServletResponse s,String path,String msg)throws IOException{r.getSession().setAttribute("flash",msg);s.sendRedirect(r.getContextPath()+path);}
    private static void showError(HttpServletRequest r,HttpServletResponse s,int status,String msg)throws ServletException,IOException{s.setStatus(status);r.setAttribute("error",msg);view(r,s,"error");}
}

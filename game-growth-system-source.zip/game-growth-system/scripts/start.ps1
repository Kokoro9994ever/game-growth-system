﻿param([string]$TomcatHome=$env:CATALINA_HOME,[string]$JavaHome=$env:JAVA_HOME,[int]$Port=8088,[switch]$Foreground)
$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot -Parent
if(-not $JavaHome -or $JavaHome -match 'jdk8'){$JavaHome='C:\Program Files\Eclipse Adoptium\jdk-21.0.13.9-hotspot'}
if(-not $TomcatHome){$TomcatHome='C:\Users\user\Documents\Codex\2026-10-20\qi\work\tools\apache-tomcat-9.0.123'}
if(-not(Test-Path "$JavaHome\bin\java.exe")){throw 'JDK 21 not found; pass -JavaHome.'}
if(-not(Test-Path "$TomcatHome\bin\catalina.bat")){throw 'Tomcat 9 not found; pass -TomcatHome.'}
$war=Join-Path $project 'target\game-growth-system.war'
if(-not(Test-Path $war)){throw 'Build first: .\scripts\build.ps1'}
$config=Join-Path $project 'config\db.local.properties'
if(-not(Test-Path $config) -and -not $env:GAME_DB_PASSWORD){throw 'Copy config/db.example.properties to config/db.local.properties and set DB credentials first.'}
$base=Join-Path $project 'runtime\tomcat'
$server=Join-Path $base 'conf\server.xml'
if(Test-Path $server){$listen=Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue;if($listen){throw "Port $Port is already in use. Stop the running server or choose -Port."}}
foreach($dir in @('conf','logs','temp','webapps','work','bin')){New-Item -ItemType Directory -Force (Join-Path $base $dir)|Out-Null}
Copy-Item "$TomcatHome\conf\*" "$base\conf" -Force
$xml=[IO.File]::ReadAllText($server).Replace('port="8080"',"port=`"$Port`"").Replace('port="8005"','port="-1"')
[IO.File]::WriteAllText($server,$xml,[Text.UTF8Encoding]::new($false))
Copy-Item $war "$base\webapps\game-growth-system.war" -Force
$env:JAVA_HOME=$JavaHome;$env:JRE_HOME=$JavaHome;$env:CATALINA_HOME=$TomcatHome;$env:CATALINA_BASE=$base
$env:CATALINA_OPTS="-Dfile.encoding=UTF-8 -Dgame.config=`"$config`""
if($Foreground){& "$TomcatHome\bin\catalina.bat" run;exit $LASTEXITCODE}
$java=Join-Path $JavaHome 'bin\java.exe'
$cp="$TomcatHome\bin\bootstrap.jar;$TomcatHome\bin\tomcat-juli.jar"
$args=@('-Dfile.encoding=UTF-8',"`"-Dgame.config=$config`"","`"-Dcatalina.home=$TomcatHome`"","`"-Dcatalina.base=$base`"","`"-Djava.io.tmpdir=$base\temp`"",'-Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager',"`"-Djava.util.logging.config.file=$base\conf\logging.properties`"",'-classpath',"`"$cp`"",'org.apache.catalina.startup.Bootstrap','start')
$proc=Start-Process -FilePath $java -ArgumentList $args -WorkingDirectory $project -WindowStyle Hidden -RedirectStandardOutput "$base\logs\stdout.log" -RedirectStandardError "$base\logs\stderr.log" -PassThru
$proc.Id|Set-Content "$base\tomcat.pid"
Write-Output "Tomcat PID: $($proc.Id) / URL: http://localhost:$Port/game-growth-system/"

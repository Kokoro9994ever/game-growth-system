﻿param([string]$BaseUrl='http://localhost:8088/game-growth-system')
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Net.Http
$handler=[Net.Http.HttpClientHandler]::new();$handler.AllowAutoRedirect=$false;$handler.CookieContainer=[Net.CookieContainer]::new()
$client=[Net.Http.HttpClient]::new($handler);$client.Timeout=[TimeSpan]::FromSeconds(90)
$script:checks=0;$script:csrf='';$script:roleId=0;$script:attributeId=0;$script:templateId=0
function Request([string]$path,[hashtable]$data=$null){
 if($null -eq $data){$response=$client.GetAsync($BaseUrl+$path).GetAwaiter().GetResult()}
 else{$dict=[Collections.Generic.Dictionary[string,string]]::new();foreach($key in $data.Keys){$dict.Add($key,[string]$data[$key])};$content=[Net.Http.FormUrlEncodedContent]::new($dict);$response=$client.PostAsync($BaseUrl+$path,$content).GetAwaiter().GetResult();$content.Dispose()}
 $html=$response.Content.ReadAsStringAsync().GetAwaiter().GetResult();$status=[int]$response.StatusCode;$response.Dispose()
 return @{Status=$status;Html=$html}
}
function Check([bool]$condition,[string]$name){if(-not $condition){throw "FAIL: $name"};$script:checks++;Write-Output "PASS: $name"}
function Token([string]$html){$match=[regex]::Match($html,'name="csrf" value="([^"]+)"');if(-not $match.Success){throw 'CSRF token missing'};return $match.Groups[1].Value}
function Mutation([string]$path,[hashtable]$data){$data.csrf=$script:csrf;return Request $path $data}
$suffix=[DateTime]::Now.ToString('HHmmss');$attrCode="TEST_$suffix";$roleCode="DEMO_$suffix"
try {
 $r=Request '/roles';Check ($r.Status -eq 302) 'Unauthenticated access redirects to login'
 $r=Request '/assets/app.css';Check ($r.Status -eq 200 -and $r.Html.Contains(':root')) 'Local stylesheet served without authentication'
 $r=Request '/assets/app.js';Check ($r.Status -eq 200 -and $r.Html.Contains('data-confirm')) 'Local JavaScript served without authentication'
 $r=Request '/login';Check ($r.Status -eq 200) 'Login JSP compiles';$script:csrf=Token $r.Html
 $r=Mutation '/login' @{username='admin';password='incorrect'};Check ($r.Status -eq 200 -and $r.Html.Contains('用户名或密码错误')) 'Wrong password rejected'
 $r=Mutation '/login' @{username='admin';password='Admin@123'};Check ($r.Status -eq 302) 'Administrator login succeeds'
 foreach($path in @('/','/roles','/attributes','/templates','/role-config','/rules','/calculate?roleId=1&level=10')){$r=Request $path;Check ($r.Status -eq 200) "JSP route $path returns HTTP 200";$script:csrf=Token $r.Html}
 $r=Request '/calculate?roleId=1&level=10';Check ($r.Html.Contains('class="result">2280</strong>')) 'Demo warrior HP at level 10 = 2280'
 $r=Request '/calculate?roleId=1&level=0';Check ($r.Status -eq 400) 'Level zero rejected'
 $r=Request '/calculate?roleId=1&level=10001';Check ($r.Status -eq 400) 'Level above maximum rejected'
 $r=Request '/roles?q=%27%20OR%201%3D1--';Check ($r.Status -eq 200 -and $r.Html.Contains('没有找到角色')) 'SQL injection search treated as literal text'
 $r=Request '/attributes' @{csrf='invalid';action='save';code='BAD';name='bad';sort_order=0};Check ($r.Status -eq 403) 'Invalid CSRF token rejected'
 $r=Mutation '/attributes' @{action='save';code=$attrCode;name='测试属性';unit='点';sort_order=99};Check ($r.Status -eq 302) 'Create attribute'
 $r=Request ("/attributes?q="+$attrCode);$script:attributeId=[int][regex]::Match($r.Html,'attributes\?edit=(\d+)').Groups[1].Value
 Check ($script:attributeId -gt 0) 'Created attribute is searchable'
 $r=Mutation '/attributes' @{action='save';id=$script:attributeId;code=$attrCode;name='测试属性已编辑';unit='%';sort_order=90};Check ($r.Status -eq 302) 'Edit attribute'
 $r=Mutation '/attributes' @{action='save';code=$attrCode;name='duplicate';unit='';sort_order=0};Check ($r.Status -eq 409) 'Duplicate attribute code rejected'
 $r=Mutation '/templates' @{action='save';name="测试方案$suffix";description='smoke test'};Check ($r.Status -eq 302) 'Create growth template'
 $r=Request ('/templates?q='+[Uri]::EscapeDataString("测试方案$suffix"));$script:templateId=[int][regex]::Match($r.Html,'templates\?edit=(\d+)').Groups[1].Value
 $r=Mutation '/templates' @{action='save';id=$script:templateId;name="测试方案$suffix";description='edited'};Check ($r.Status -eq 302) 'Edit growth template'
 $r=Mutation '/roles' @{action='save';code=$roleCode;name='自动测试角色';profession='战士';rarity='SR';growth_template_id=$script:templateId;description='integration test'};Check ($r.Status -eq 302) 'Create role and assign template'
 $r=Request ('/roles?q='+$roleCode);$script:roleId=[int][regex]::Match($r.Html,'roles\?edit=(\d+)').Groups[1].Value
 Check ($script:roleId -gt 0) 'Created role is searchable'
 $r=Mutation '/roles' @{action='save';id=$script:roleId;code=$roleCode;name='<script>alert(1)</script>';profession='法师';rarity='SSR';growth_template_id=$script:templateId;description='edited'};Check ($r.Status -eq 302) 'Edit role'
 $r=Request ('/roles?q='+$roleCode);Check ($r.Html.Contains('&lt;script&gt;alert(1)&lt;/script&gt;') -and -not $r.Html.Contains('<script>alert(1)</script>')) 'Stored text is HTML escaped'
 $r=Request ("/role-config?roleId="+$script:roleId);$base=@{roleId=$script:roleId};foreach($m in [regex]::Matches($r.Html,'name="(value_\d+)"')){$base[$m.Groups[1].Value]='100.5'}
 $r=Mutation '/role-config' $base;Check ($r.Status -eq 302) 'Save role base attributes'
 $r=Request ("/rules?templateId="+$script:templateId);$rules=@{templateId=$script:templateId};foreach($m in [regex]::Matches($r.Html,'name="(value_\d+)"')){$rules[$m.Groups[1].Value]='2.75'}
 $r=Mutation '/rules' $rules;Check ($r.Status -eq 302) 'Save growth rules'
 $r=Request ("/calculate?roleId="+$script:roleId+'&level=10');Check ($r.Status -eq 200 -and ([regex]::Matches($r.Html,'class="result">125.25</strong>').Count -ge 6)) 'All configured attributes: 100.5 + 2.75 x 9 = 125.25'
 $r=Request ("/calculate?roleId="+$script:roleId+'&level=1');Check ($r.Html.Contains('class="result">100.5</strong>')) 'Level 1 equals base value'
 $invalid=$base.Clone();$keys=@($base.Keys|Where-Object {$_ -like 'value_*'}|Sort-Object);$invalid[$keys[0]]='999';$invalid[$keys[1]]='-1';$r=Mutation '/role-config' $invalid;Check ($r.Status -eq 400) 'Negative attribute value rejected'
 $r=Request ("/calculate?roleId="+$script:roleId+'&level=1');Check (([regex]::Matches($r.Html,'class="result">100.5</strong>').Count -ge 6) -and -not $r.Html.Contains('class="result">999</strong>')) 'Invalid batch causes complete transaction rollback'
 $r=Mutation '/attributes' @{action='delete';id=$script:attributeId};Check ($r.Status -eq 302) 'Delete attribute with dependent values and rules';$script:attributeId=0
 $r=Mutation '/templates' @{action='delete';id=$script:templateId};Check ($r.Status -eq 302) 'Delete template assigned to role';$script:templateId=0
 $r=Request ("/calculate?roleId="+$script:roleId+'&level=10');Check ($r.Html.Contains('未分配') -and $r.Html.Contains('class="result">100.5</strong>')) 'Deleted template leaves role valid with zero growth'
 $r=Mutation '/roles' @{action='delete';id=$script:roleId};Check ($r.Status -eq 302) 'Delete role';$script:roleId=0
 $r=Mutation '/logout' @{};Check ($r.Status -eq 302) 'Logout succeeds'
 $r=Request '/calculate';Check ($r.Status -eq 302) 'Session invalidated after logout'
 Write-Output "SUCCESS: $script:checks integration checks passed."
}finally{
 foreach($pair in @(@('/roles',$script:roleId),@('/attributes',$script:attributeId),@('/templates',$script:templateId))){if($pair[1] -gt 0){try{$null=Mutation $pair[0] @{action='delete';id=$pair[1]}}catch{Write-Warning 'Test cleanup failed; remove TEST/DEMO records manually.'}}}
 $client.Dispose();$handler.Dispose()
}

package com.game;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;
class GrowthCalculatorTest {
    @Test void firstLevelReturnsBase(){assertEquals(new BigDecimal("100.50"),GrowthCalculator.calculate(new BigDecimal("100.50"),new BigDecimal("2.75"),1));}
    @Test void exactDecimalGrowth(){assertEquals(new BigDecimal("125.25"),GrowthCalculator.calculate(new BigDecimal("100.50"),new BigDecimal("2.75"),10));}
    @Test void demoWarriorLevelTen(){assertEquals(new BigDecimal("2280"),GrowthCalculator.calculate(new BigDecimal("1200"),new BigDecimal("120"),10));}
    @Test void zeroGrowth(){assertEquals(new BigDecimal("5"),GrowthCalculator.calculate(new BigDecimal("5"),BigDecimal.ZERO,10000));}
    @Test void levelBounds(){assertThrows(IllegalArgumentException.class,()->GrowthCalculator.calculate(BigDecimal.ONE,BigDecimal.ONE,0)); assertThrows(IllegalArgumentException.class,()->GrowthCalculator.calculate(BigDecimal.ONE,BigDecimal.ONE,10001));}
}

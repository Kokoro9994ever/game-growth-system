package com.game;

import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

public final class Db {
    private Db() {}
    private static final Properties CONFIG = load();
    private static Properties load() {
        Properties p = new Properties();
        String file = System.getProperty("game.config", System.getenv("GAME_CONFIG"));
        if (file == null) file = "config/db.local.properties";
        Path path = Path.of(file);
        if (Files.exists(path)) try (InputStream in = Files.newInputStream(path)) { p.load(in); }
        catch (IOException e) { throw new IllegalStateException("Cannot read database config", e); }
        return p;
    }
    private static String get(String key, String env, String fallback) {
        String value = System.getenv(env);
        return value != null ? value : CONFIG.getProperty(key, fallback);
    }
    public static Connection open() throws SQLException {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); }
        catch(ClassNotFoundException e) { throw new SQLException("MySQL JDBC driver is missing",e); }
        return DriverManager.getConnection(get("db.url", "GAME_DB_URL", "jdbc:mysql://127.0.0.1:3306/game_growth_system?characterEncoding=UTF-8&serverTimezone=Asia/Shanghai"), get("db.user", "GAME_DB_USER", "game_growth_app"), get("db.password", "GAME_DB_PASSWORD", ""));
    }
    public static List<Map<String,Object>> query(String sql, Object... args) throws SQLException {
        try (Connection c = open(); PreparedStatement s = c.prepareStatement(sql)) {
            bind(s,args);
            try (ResultSet rs = s.executeQuery()) {
                List<Map<String,Object>> rows = new ArrayList<>();
                while (rs.next()) {
                    Map<String,Object> row = new LinkedHashMap<>();
                    for (int i=1;i<=rs.getMetaData().getColumnCount();i++) row.put(rs.getMetaData().getColumnLabel(i),rs.getObject(i));
                    rows.add(row);
                }
                return rows;
            }
        }
    }
    public static int update(String sql, Object... args) throws SQLException {
        try (Connection c = open(); PreparedStatement s = c.prepareStatement(sql)) { bind(s,args); return s.executeUpdate(); }
    }
    public static void bind(PreparedStatement s,Object... args) throws SQLException { for(int i=0;i<args.length;i++) s.setObject(i+1,args[i]); }
}

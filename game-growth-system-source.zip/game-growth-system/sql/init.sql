-- MySQL 8.4 / UTF-8. Non-destructive: existing tables and records are preserved.
CREATE DATABASE IF NOT EXISTS game_growth_system CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE game_growth_system;
CREATE TABLE IF NOT EXISTS admin_user (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, username VARCHAR(80) NOT NULL UNIQUE,
 salt VARCHAR(64) NOT NULL, password_hash CHAR(64) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS growth_template (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(80) NOT NULL UNIQUE, description VARCHAR(500) NOT NULL DEFAULT ''
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS game_role (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, code VARCHAR(32) NOT NULL UNIQUE, name VARCHAR(80) NOT NULL,
 profession VARCHAR(40) NOT NULL, rarity VARCHAR(10) NOT NULL DEFAULT 'R', description VARCHAR(500) NOT NULL DEFAULT '',
 growth_template_id BIGINT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_role_template FOREIGN KEY (growth_template_id) REFERENCES growth_template(id) ON DELETE SET NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS attribute_definition (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, code VARCHAR(32) NOT NULL UNIQUE, name VARCHAR(80) NOT NULL,
 unit VARCHAR(20) NOT NULL DEFAULT '',sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS role_attribute (
 role_id BIGINT NOT NULL, attribute_id BIGINT NOT NULL, base_value DECIMAL(13,4) NOT NULL DEFAULT 0,
 PRIMARY KEY(role_id,attribute_id), CHECK (base_value>=0),
 FOREIGN KEY(role_id) REFERENCES game_role(id) ON DELETE CASCADE,
 FOREIGN KEY(attribute_id) REFERENCES attribute_definition(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS growth_rule (
 template_id BIGINT NOT NULL, attribute_id BIGINT NOT NULL, per_level DECIMAL(13,4) NOT NULL DEFAULT 0,
 PRIMARY KEY(template_id,attribute_id), CHECK(per_level>=0),
 FOREIGN KEY(template_id) REFERENCES growth_template(id) ON DELETE CASCADE,
 FOREIGN KEY(attribute_id) REFERENCES attribute_definition(id) ON DELETE CASCADE
) ENGINE=InnoDB;
INSERT IGNORE INTO admin_user(id,username,salt,password_hash) VALUES(1,'admin','game-growth-demo-v1',SHA2(CONCAT('game-growth-demo-v1','Admin@123'),256));
INSERT IGNORE INTO growth_template(id,name,description) VALUES(1,'均衡成长','兼顾生存与输出，适合战士'),(2,'爆发输出','高攻击成长，适合法师与射手'),(3,'坚韧守护','高生命与防御成长，适合坦克');
INSERT IGNORE INTO attribute_definition(id,code,name,unit,sort_order) VALUES(1,'HP','生命值','点',10),(2,'ATK','攻击力','点',20),(3,'DEF','防御力','点',30),(4,'SPD','速度','点',40),(5,'CRIT','暴击率','%',50);
INSERT IGNORE INTO game_role(id,code,name,profession,rarity,growth_template_id,description) VALUES
 (1,'WARRIOR_001','晨曦剑士','战士','SSR',1,'以长剑守护晨曦的近战勇者'),(2,'MAGE_001','星霜法师','法师','SSR',2,'掌握星辰与寒霜的远程施法者'),(3,'GUARD_001','磐石守卫','坦克','SR',3,'坚不可摧的队伍壁垒'),(4,'ARCHER_001','逐风游侠','射手','SR',2,'以精准箭术追逐疾风');
INSERT IGNORE INTO role_attribute(role_id,attribute_id,base_value) VALUES
 (1,1,1200),(1,2,85),(1,3,60),(1,4,100),(1,5,5),
 (2,1,800),(2,2,120),(2,3,35),(2,4,95),(2,5,8),
 (3,1,1800),(3,2,55),(3,3,110),(3,4,75),(3,5,3),
 (4,1,950),(4,2,100),(4,3,40),(4,4,120),(4,5,12);
INSERT IGNORE INTO growth_rule(template_id,attribute_id,per_level) VALUES
 (1,1,120),(1,2,8.5),(1,3,6),(1,4,1.2),(1,5,0.15),
 (2,1,65),(2,2,14),(2,3,3),(2,4,1.8),(2,5,0.25),
 (3,1,180),(3,2,5),(3,3,11),(3,4,0.8),(3,5,0.1);

package com.game;
import java.security.*;
import java.util.HexFormat;
public final class Passwords {
    private Passwords() {}
    public static boolean verify(String password, String salt, String expected) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest((salt+password).getBytes(java.nio.charset.StandardCharsets.UTF_8));
            return MessageDigest.isEqual(hash,HexFormat.of().parseHex(expected));
        } catch (NoSuchAlgorithmException | IllegalArgumentException e) { return false; }
    }
}

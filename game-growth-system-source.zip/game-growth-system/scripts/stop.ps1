﻿$ErrorActionPreference='Stop'
$base=Join-Path (Split-Path $PSScriptRoot -Parent) 'runtime\tomcat'
$file=Join-Path $base 'tomcat.pid'
if(-not(Test-Path $file)){Write-Output 'No managed Tomcat process found.';exit}
$tomcatProcessId=[int](Get-Content $file)
$process=Get-CimInstance Win32_Process -Filter "ProcessId=$tomcatProcessId" -ErrorAction SilentlyContinue
if($process -and $process.CommandLine.Contains("-Dcatalina.base=$base")) {Stop-Process -Id $tomcatProcessId;Write-Output 'Project Tomcat stopped.'}
elseif($process){throw 'Process identity changed; refusing to stop an unrelated process.'}
Remove-Item -LiteralPath $file

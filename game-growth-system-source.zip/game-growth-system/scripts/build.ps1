﻿param([string]$JavaHome=$env:JAVA_HOME)
$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot -Parent
if(-not $JavaHome -or -not (Test-Path "$JavaHome\bin\javac.exe") -or $JavaHome -match 'jdk8') {
 $JavaHome='C:\Program Files\Eclipse Adoptium\jdk-21.0.13.9-hotspot'
}
if(-not (Test-Path "$JavaHome\bin\javac.exe")){throw 'Set JAVA_HOME to your JDK 21 installation.'}
$env:JAVA_HOME=$JavaHome
Push-Location $project
try { & mvn clean package; if($LASTEXITCODE -ne 0){throw 'Maven build failed'} } finally {Pop-Location}

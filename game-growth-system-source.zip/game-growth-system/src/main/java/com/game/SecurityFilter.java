package com.game;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.UUID;

@WebFilter("/*")
public class SecurityFilter implements Filter {
    @Override public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req=(HttpServletRequest)request; HttpServletResponse res=(HttpServletResponse)response;
        req.setCharacterEncoding("UTF-8"); res.setCharacterEncoding("UTF-8");
        res.setHeader("X-Content-Type-Options","nosniff"); res.setHeader("X-Frame-Options","DENY");
        res.setHeader("Content-Security-Policy","default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'");
        String path=req.getServletPath();
        if(path.startsWith("/assets/")){chain.doFilter(req,res);return;}
        res.setHeader("Cache-Control","no-store");
        HttpSession session=req.getSession();
        if(session.getAttribute("csrf")==null) session.setAttribute("csrf", UUID.randomUUID().toString());
        if(!path.equals("/login") && session.getAttribute("admin")==null){res.sendRedirect(req.getContextPath()+"/login");return;}
        if(req.getMethod().equals("POST") && !session.getAttribute("csrf").equals(req.getParameter("csrf"))){res.sendError(403,"页面已过期，请刷新后重试");return;}
        chain.doFilter(req,res);
    }
}

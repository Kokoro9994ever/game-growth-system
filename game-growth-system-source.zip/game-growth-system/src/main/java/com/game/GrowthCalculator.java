package com.game;
import java.math.BigDecimal;
public final class GrowthCalculator {
    private GrowthCalculator() {}
    public static BigDecimal calculate(BigDecimal base, BigDecimal perLevel, int level) {
        if(level<1 || level>10000) throw new IllegalArgumentException("目标等级必须在 1–10000 之间");
        if(base==null || perLevel==null) throw new IllegalArgumentException("属性值不能为空");
        return base.add(perLevel.multiply(BigDecimal.valueOf(level-1L)));
    }
}
